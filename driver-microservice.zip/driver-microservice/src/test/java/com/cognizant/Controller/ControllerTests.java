package com.cognizant.Controller;

import com.cognizant.controller.DriverController;


import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ControllerTests {

    DriverController driverController = new DriverController();


    @Test
    @DisplayName("Checking if [DriverController] is loading or not.")
    void driverControllerisloaded(){
        assertThat(driverController).isNotNull();
    }
}



