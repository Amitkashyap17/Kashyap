package com.cognizant.Model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import com.cognizant.model.Driver;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ModelTests {
    Driver driver;

    @Test
    void testDriverDetails() {
        driver = new Driver("LKJHUGYV17689","Dravid",21,"SUV");
        assertEquals("SUV",driver.getVehicleType());
    }
}