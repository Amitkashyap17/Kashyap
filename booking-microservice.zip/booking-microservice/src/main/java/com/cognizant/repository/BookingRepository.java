package com.cognizant.repository;

import com.cognizant.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findAllBySdTime(String sdTime);

    List<Booking> findAllBySdTimeAndEdTime(String sdTime, String edTime);
}
