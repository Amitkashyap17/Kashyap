package com.cognizant.model;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="vehicles")
public class VehicleDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    private String registrationNo;

    @Column
    private String modelName;

    @Column
    private String vehicleType;

    @Column
    private int numberOfSeat;

    @Column
    private boolean acAvailable;
}
