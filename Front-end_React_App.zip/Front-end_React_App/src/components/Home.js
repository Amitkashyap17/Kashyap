import React from "react";
import axios from "axios";
import "./Home.css"

class Home extends React.Component {
  setCookie(name, value, mins) {
    var expires = "";
    if (mins) {
      var date = new Date();
      date.setTime(date.getTime() + mins * 60 * 60 * 1000);
      expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + (value || "") + expires + "; path=/";
  }

  getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(";");
    for (var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == " ") c = c.substring(1, c.length);
      if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
  }
  validate = async () => {
    const token = this.getCookie("token");
    console.log(token);
    try {
      const data = await axios.get(`http://localhost:8100/api/validate`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      this.setCookie("loggedIn", true, 30);
    } catch (error) {
      alert("User Not Authourized please try logging in again");
      this.setCookie("token", null);
      this.setCookie("loggedIn", null);
      this.setCookie("user", null);
      window.location.pathname = "/login";
    }
  };

  componentDidMount() {
    this.validate();
  }

  render() {
    return (
      <div class="row row-cols-1 row-cols-md-3 g-4">
        <div class="col-sm-3">
          <a href="/drivers" style={{ textDecoration: "none", color: "black" }}>
            <div class="card h-85 trf" style={{ backgroundColor: "lavender" }}>
              <img
                src="https://bigcars.com/wp-content/uploads/2016/06/ThinkstockPhotos-147043523.jpg"
                class="card-img-top"
                alt="..."
                height="60%"
              />
              <div class="card-body">
                <h5 class="card-title">Drivers</h5>
                <p class="card-text ">
                  Click here to get details of all the drivers working under the
                  company.
                  <br /> You can also add and delete drivers and edit thier
                  details....
                </p>
              </div>
              
            </div>
          </a>
        </div>
        <div class="col-sm-3">
          <a
            href="/vehicles"
            style={{ textDecoration: "none", color: "black" }}
          >
            <div class="card h-85 trf" style={{ backgroundColor: "lavender" }}>
              <img
                src="https://m.economictimes.com/thumb/msid-92811339,width-1200,height-900,resizemode-4,imgsize-67386/luxury-vehicle-sales-in-india-grew-in-strong-double-digits-in-first-half-of-2022.jpg"
                class="card-img-top"
                alt="..."
                height="60%"
              />
              <div class="card-body">
                <h5 class="card-title">Vehicles</h5>
                <p class="card-text">
                  Click here to get details of all the vehicles working under
                  the company.
                  <br /> You can also add and delete vehicles and edit thier
                  details....
                </p>
              </div>
              
            </div>
          </a>
        </div>
        <div class="col-sm-3">
          <a
            href="/bookings"
            style={{ textDecoration: "none", color: "black" }}
          >
            <div class="card h-85 trf" style={{ backgroundColor: "lavender" }}>
              <img
                src="https://firebasestorage.googleapis.com/v0/b/webapps-a490f.appspot.com/o/booking.jpg?alt=media"
                class="card-img-top"
                alt="..."
                height="60%"
              />
              <div class="card-body">
                <h5 class="card-title">Booking</h5>
                <p class="card-text">
                Click here to get details of all the bookings under the
                  company.
                  <br /> You can also add and delete bookings and edit thier
                  details....
                </p>
              </div>
              
            </div>
          </a>
        </div>
      </div>
    );
  }
}

export default Home;
