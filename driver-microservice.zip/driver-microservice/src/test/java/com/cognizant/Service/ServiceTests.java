package com.cognizant.Service;

import static org.assertj.core.api.Assertions.assertThat;


import com.cognizant.service.DriverService;
import com.cognizant.service.impl.DriverServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;


import com.cognizant.model.Driver;

@SpringBootTest
public class ServiceTests {

    DriverServiceImpl driverServiceImpl = new DriverServiceImpl();

    Driver driver_details = new Driver();

    @Test
    @DisplayName("Checking if [DriverServiceImpl] is loading or not.")
    void driverServiceImplIsLoaded(){
        assertThat(driverServiceImpl).isNotNull();
    }

    @Test
    void testProcessDriverService() {
        driver_details.setLicenceNumber("1234567");
        driver_details.setName("an");
        driver_details.setAge(21);
        driver_details.setVehicleType("SUV");


        assertThat(driverServiceImpl).isNotNull();
    }

}