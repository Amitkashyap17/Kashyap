package com.cognizant.repository;

import com.cognizant.model.Driver;
//import com.sun.org.apache.xpath.internal.operations.Bool;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface DriverRepository extends JpaRepository<Driver, String> {
    List<Driver> findAllByVehicleType(String vehicleType);

    @Query("" +
            "SELECT CASE WHEN COUNT(s) > 0 THEN " +
            "TRUE ELSE FALSE END " +
            "FROM Driver s " +
            "WHERE s.name = ?1"
    )
    Boolean isDriverExistsByName(String name);

}
