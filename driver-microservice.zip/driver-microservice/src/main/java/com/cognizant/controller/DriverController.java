package com.cognizant.controller;

import com.cognizant.model.Driver;
import com.cognizant.service.DriverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3000")
public class DriverController {

    @Autowired
    private DriverService driverService;


    //build create driver REST API
    @PostMapping("/drivers")
    public ResponseEntity<Driver> saveDriver(@RequestBody Driver driver){
        return  new ResponseEntity<Driver>(driverService.saveDriver(driver), HttpStatus.CREATED);
    }

    //build get all drivers REST API
    @GetMapping("/drivers")
    public List<Driver> getAllDrivers(){
        return driverService.getAllDrivers();
    }

    @GetMapping("/{vehicleType}")
    public  List<Driver> getDriversByVehicleType(@PathVariable(name="vehicleType") String vehicleType){
        return driverService.getDriversByVehicleType(vehicleType);
    }

    @DeleteMapping("/{licenceNumber}")
    public ResponseEntity<String> deleteDriver(@PathVariable(name="licenceNumber") String licenceNumber){
        try{
            driverService.deleteDriver(licenceNumber);
            return new ResponseEntity<String>("Driver Deleted Successfully!.", HttpStatus.OK);
        }catch (Exception e){
            return new ResponseEntity<String>("Please Enter a Valid License Number.",HttpStatus.NOT_FOUND);
        }
    }
}
